#!/bin/bash
set -e

# This script checks all the fonts in a directory using 'chkfont'.
# If no errors are reported, warnings can be shown.
#
# Usage:
#  ./check-fonts DIR [-w]
#      DIR   A (sub)directory path.
#      -w    Show warnings (if font has no errors)
#
#  e.g. ./check-fonts  contributed
#  e.g. ./check-fonts  contributed/C64-fonts

DIR=.
if [ $# -gt 0 ]; then
    DIR="$1"
fi

for fil in `ls ./$DIR/*.flf`; do
  echo "Checking $fil"
  if ! ./figlet-2.2.5/chkfont $fil | grep -q "Errors: 0"; then
      ./figlet-2.2.5/chkfont $fil
  elif [ "$2" = "-w" ]; then
      if ! ./figlet-2.2.5/chkfont $fil | grep -q "Warnings: 0"; then
          ./figlet-2.2.5/chkfont $fil
      fi
  fi
done
