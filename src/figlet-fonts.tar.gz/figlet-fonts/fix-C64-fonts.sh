#!/bin/bash
set -e

# The current Figlet spec (version 2.2.5) requires that fonts define the
# chars: 196, 214, 220, 228, 246, 252, 223.
#
# This script adds seven blank characters to the C64 font files in order
# to bring the font files into alignment with the Figlet specification.
#
# This script should only need to be run once. Running this script a second
# time should not alter the font files again.

for fil in `ls ./contributed/C64-fonts/*flf`; do
  if ./figlet-2.2.5/chkfont $fil | grep -q "Errors: 1"; then
      echo "Editing $fil"
      for n in 196, 214, 220, 228, 246, 252, 223; do # 
          (
              echo "$        @"
              echo "$        @"
              echo "$        @"
              echo "$        @"
              echo "$        @"
              echo "$        @"
              echo "$        @"
              echo "$        @@"
          ) >> $fil
      done
  fi
done


# Check the font files for errors.
for fil in `ls ./contributed/C64-fonts/*flf`; do
  if ! ./figlet-2.2.5/chkfont $fil | grep -q "Errors: 0"; then
     echo "Error: $fil still has errors."
  fi
done
