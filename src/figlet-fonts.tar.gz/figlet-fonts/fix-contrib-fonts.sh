#!/bin/bash
set -e

# Update specific font files to allow them to pass 'chkfont'.
#
# This script should only need to be run once. Running this script a second
# time should not alter the font files again.

DWHISTLED=./contributed/dwhistled.flf
if ./figlet-2.2.5/chkfont $DWHISTLED | grep -q "Errors: 9"; then

    echo "Editing $DWHISTLED"

    # Replace ending char to prevent '@@' sequence.
    sed -i -e '334s/@@/@#/'   $DWHISTLED
    sed -i -e '335s/ @/ #/'   $DWHISTLED
    sed -i -e '336s/ @/ #/'   $DWHISTLED
    sed -i -e '337s/ @/ #/'   $DWHISTLED
    sed -i -e '338s/ @/ #/'   $DWHISTLED
    sed -i -e '339s/ @/ #/'   $DWHISTLED
    sed -i -e '340s/ @/ #/'   $DWHISTLED
    sed -i -e '341s/ @/ #/'   $DWHISTLED
    sed -i -e '342s/@@/@#/'   $DWHISTLED
    sed -i -e '343s/ @@/ ##/' $DWHISTLED

    # Delete last two lines.
    sed -i -e '$d' $DWHISTLED
    sed -i -e '$d' $DWHISTLED

    # Add (empty) characters for required char codes.
    for n in 196, 214, 220, 228, 246, 252, 223; do
        (
            echo " @"
            echo " @"
            echo " @"
            echo " @"
            echo " @"
            echo " @"
            echo " @"
            echo " @"
            echo " @"
            echo " @@"
        ) >> $DWHISTLED
    done
fi





GRADIENT=./contributed/gradient.flf
if ./figlet-2.2.5/chkfont $GRADIENT | grep -q "Errors: 20"; then
    echo "Editing $GRADIENT"
    sed -i -e '846i ****|||**$' $GRADIENT  # Insert line
    sed -i -e 's/\r//g' $GRADIENT # Convert line-endings to UNIX (from DOS)
fi





MAXFOUR=./contributed/maxfour.flf
if ./figlet-2.2.5/chkfont $MAXFOUR | grep -q "Warnings: 1"; then
    echo "Editing $MAXFOUR"
    # Delete last line.
    sed -i -e '$d' $MAXFOUR
fi





SLSCRIPT=./contributed/slscript.flf
if ./figlet-2.2.5/chkfont $SLSCRIPT | grep -q "Errors: 1"; then
    echo "Editing $SLSCRIPT"
   sed -i -e '96s/$$@@/$$$@@/'   $SLSCRIPT
fi











# Check the font files for errors.
for fil in `ls ./contributed/*.flf`; do
    if ! ./figlet-2.2.5/chkfont $fil | grep -q "Errors: 0"; then
        echo "Error: $fil still has errors."
    fi
done
