#!/bin/bash
set -e

# The current Figlet spec (version 2.2.5) does not allow -1 as a code tag.
#
# This script modifies selected code tags of -1 to be -100.
#
# This script should only need to be run once. Running this script a second
# time should not alter the font files again.


# Replace invalid '-1' with '-100'.
for fil in `ls ./contributed/bdffonts/*flf`; do
    if ./figlet-2.2.5/chkfont $fil | grep -q "ERROR- Code tag -1"; then
        echo "Editing $fil"
        sed -i -e 's/-1 tilde/-100 tilde/' $fil
        sed -i -e 's/-1 circumflex/-100 circumflex/' $fil
    fi
done




# Correct font line height
F5X8=./contributed/bdffonts/5x8.flf
sed -i -e 's/ 8 8 25 / 9 8 25 /' $F5X8 # Each char is 9 lines, not 8.
if ./figlet-2.2.5/chkfont $F5X8 | grep -q "Errors: 7"; then
    echo "Editing $F5X8"
    sed -i -e '950i @' $F5X8  # Insert line
    sed -i -e '942i @' $F5X8  # Insert line
    sed -i -e '934i @' $F5X8  # Insert line
    sed -i -e '926i @' $F5X8  # Insert line
    sed -i -e '918i @' $F5X8  # Insert line
    sed -i -e '910i @' $F5X8  # Insert line
    sed -i -e '902i @' $F5X8  # Insert line
fi





# Check the font files for errors.
for fil in `ls ./contributed/bdffonts/*flf`; do
  if ! ./figlet-2.2.5/chkfont $fil | grep -q "Errors: 0"; then
     echo "Error: $fil still has errors."
     ./figlet-2.2.5/chkfont $fil
  fi
done
